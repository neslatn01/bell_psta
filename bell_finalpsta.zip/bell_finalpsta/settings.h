                           
                           
                           /////////////////////////////////////////////////////////////////
                          //                           Settings                          //
                         /////////////////////////////////////////////////////////////////

                         

/***************************************************
 *      Hardware Settings
 **************************************************/

/* Relay to NodeMCU Connection */

#define RELAY_PIN_1     5  //D1
#define RELAY_PIN_2      16   //D0
#define RELAY_PIN_3       4   //D2
 

/* NodeMCU to Push Button switch  */
/*
  For push button/switch action I don't have push button so I will be keep those wire open and 
  touch each of these wires with GND wire on NodeMCU to perform On and OFF action.
 */
 
#define PUSH_BUTTON_1     13   //D7
#define PUSH_BUTTON_2    12   //D6
#define PUSH_BUTTON_3    14   //D5
 

/***************************************************
 *        Blynk Virtual Pin Assignment
 **************************************************/

#define VPIN_BUTTON_1    V0
#define VPIN_BUTTON_2    V23
#define VPIN_BUTTON_3    V24
 
/***************************************************
 *        Server Settings
 **************************************************/
      
#define OTA_HOSTNAME "4 Channel Relay with Button Sync"
 
